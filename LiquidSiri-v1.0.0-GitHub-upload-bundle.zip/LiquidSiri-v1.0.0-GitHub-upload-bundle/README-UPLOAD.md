# Liquid Siri V1.0.0 — GitHub upload guide

Upload these two files to the root of a new private GitHub repository:

1. `LiquidSiri-Android-v1.0.0-source.zip`
2. `.github/workflows/build.yml` (create the folders `.github/workflows` and upload this file there; use the `build.yml` included in the separate bundle)

After both are committed, open the repository's **Actions** tab. Select **Build Liquid Siri Android APK** and run it if it has not started automatically. On success, download the `LiquidSiri-V1-debug-APK` artifact and extract it to get `app-debug.apk`.

The source ZIP is a native Android Gradle project with `LiquidGlassCenter/` at its root. Do not upload the larger GitHub bundle ZIP in place of the source ZIP.
